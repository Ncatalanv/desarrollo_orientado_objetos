/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2.pkg2.pkg2;

import java.util.ArrayList;

/**
 *
 * @author Cetecom
 */
public class Pedido {
    private ArrayList<Producto> productos;
    private double total;

    public Pedido() {
    }

    public Pedido(ArrayList<Producto> productos, double total) {
        this.productos = productos;
        this.total = total;
    }

    public ArrayList<Producto> getProductos() {
        return productos;
    }

    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    
    
    
}
