/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2.pkg2.pkg2;

/**
 *
 * @author Cetecom
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Electronico electronico1 = new Electronico("marca", 12, "id123", "celular", 250000);
        
        Double precioConDescuento = electronico1.calcularDescuento(75);
        System.out.println("El valor con descuento es "+precioConDescuento);
        
        int garantiaExtendida = electronico1.extenderGarantia(7);
        System.out.println("El " + electronico1.getNombre()+" con la garantía extendida quedará en "+ garantiaExtendida + " meses.");
        
        Ropa ropa1 = new Ropa("L", "blanco", "id455", "polera", 35000);
        String tallaNueva = ropa1.ajustarTalla("m");
        System.out.println("La talla nueva sera: "+tallaNueva); 
        
        
        
        
        
            }
    
}
